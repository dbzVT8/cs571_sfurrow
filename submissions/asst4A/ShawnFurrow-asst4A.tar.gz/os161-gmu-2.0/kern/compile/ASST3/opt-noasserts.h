/* Automatically generated; do not edit */
#ifndef _OPT_NOASSERTS_H_
#define _OPT_NOASSERTS_H_
#define OPT_NOASSERTS 0
#endif /* _OPT_NOASSERTS_H_ */
